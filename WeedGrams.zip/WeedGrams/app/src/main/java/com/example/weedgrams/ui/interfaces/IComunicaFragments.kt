package com.example.weedgrams.ui.interfaces

public interface IComunicaFragments {

    public fun iniciarFragment()



}