package com.example.weedgrams.ui.comon

class Plantas (val tituloCultivo: String = " ", val tiempoInvertido:String = "",val fenotipoPlanta:String =""){



}