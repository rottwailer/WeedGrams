package com.example.weedgrams.ui.comon

class Usuario(val usuario:String, val contraseña:String) {
}