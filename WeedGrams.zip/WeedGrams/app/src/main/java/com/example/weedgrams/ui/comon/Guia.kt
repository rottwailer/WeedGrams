package com.example.weedgrams.ui.comon

class Guia(val tituloCultivo: String = " ",val dineroInvertido:String = " ",val dificultadValor:String = "", val tiempoInvertido:String = "",val fenotipoPlanta:String ="") {
}