package com.example.weedgrams.ui.logeo

import android.text.Editable
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.weedgrams.R
import com.example.weedgrams.databinding.FragmentLogearseBinding

class LogearseViewModel : ViewModel() {


   val _usuario  = MutableLiveData<String>()
   val usuario: String = _usuario.toString()


   val _contra: Editable? = contras
   val contra:String = _contra.toString()

    init {
        _usuario.value
    }


}