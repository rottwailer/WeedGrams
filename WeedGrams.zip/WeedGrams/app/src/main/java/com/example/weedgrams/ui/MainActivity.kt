package com.example.weedgrams.ui

import android.os.Bundle
import android.widget.Toast
import com.google.android.material.bottomnavigation.BottomNavigationView
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupWithNavController
import com.example.weedgrams.R
import com.example.weedgrams.databinding.ActivityMainBinding
import com.example.weedgrams.databinding.FragmentGuiasBinding
import com.example.weedgrams.ui.interfaces.IComunicaFragments

class MainActivity : AppCompatActivity(), IComunicaFragments  {


    private lateinit var bindingGuias: FragmentGuiasBinding
    private lateinit var bindingMain: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {

        setTheme(R.style.AppTheme)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val navView: BottomNavigationView = bindingMain.navView

        val navController = findNavController(R.id.nav_host_fragment)
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
       /* val appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.navigation_home,
                R.id.navigation_dashboard,
                R.id.navigation_notifications
            )
        )*/
        navView.setupWithNavController(navController)


    }

    override fun iniciarFragment() {

        Toast.makeText(applicationContext,"Iniciar Fragment",Toast.LENGTH_SHORT).show()


    }

}
