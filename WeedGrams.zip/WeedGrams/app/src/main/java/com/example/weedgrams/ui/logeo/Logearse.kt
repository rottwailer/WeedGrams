package com.example.weedgrams.ui.logeo


import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.fragment.findNavController

import com.example.weedgrams.R
import com.example.weedgrams.databinding.FragmentLogearseBinding
import com.example.weedgrams.ui.comon.Usuario
import com.example.weedgrams.ui.home.HomeViewModel
import com.example.weedgrams.ui.logo.logoDirections
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

/**
 * A simple [Fragment] subclass.
 */
class Logearse : Fragment() {

    private lateinit var bindingLogearse: FragmentLogearseBinding
    private lateinit var logearseViewModel: LogearseViewModel
    private lateinit var database: DatabaseReference// ...
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
//https://firebase.google.com/docs/database/android/read-and-write?hl=es
        //https://medium.com/knowing-android/animaciones-y-transiciones-en-android-parte-1-3bd2d2e9625d
        bindingLogearse = DataBindingUtil.inflate(inflater, R.layout.fragment_logearse,container,false)

        logearseViewModel = ViewModelProviders.of(this).get(LogearseViewModel::class.java)

        var usuario:String = ""
        var contraseña:String=""

        bindingLogearse.buttonRegister.setOnClickListener{
            //this.findNavController().navigate(logoD)
        }
        bindingLogearse.buttonLogging.setOnClickListener{
            usuario = logearseViewModel.usuario
            contraseña = logearseViewModel.contra
            writeNewUser(usuario,contraseña)
        }
        database = FirebaseDatabase.getInstance().reference


        return bindingLogearse.root
    }
    private fun writeNewUser (usuario: String, contraseña: String) {
        val user = Usuario(usuario, contraseña)
        database.child("usuarios").child(usuario).setValue(user)
    }




}
